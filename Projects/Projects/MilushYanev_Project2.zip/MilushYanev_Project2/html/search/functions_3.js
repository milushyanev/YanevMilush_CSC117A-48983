var searchData=
[
  ['deletelink',['deleteLink',['../navtree_8js.html#abdf8e0e69c89803c1b84784a13b7fd2e',1,'navtree.js']]],
  ['developer',['Developer',['../class_developer.html#a1acf937b03598b68b93c010bfc90f702',1,'Developer::Developer()'],['../class_developer.html#a24c1cde234cb63807179251c8516f69e',1,'Developer::Developer(string, int, string)'],['../class_developer.html#a70d27630049849deaf3fbc8fab301908',1,'Developer::Developer(const Developer &amp;orig)']]]
];
