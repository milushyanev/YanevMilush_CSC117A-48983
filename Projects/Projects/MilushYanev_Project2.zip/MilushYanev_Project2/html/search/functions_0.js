var searchData=
[
  ['ai_5fbns',['AI_Bns',['../class_bonus.html#ae2f51b8407ff820aa8a0a180d2158554',1,'Bonus']]]
];
