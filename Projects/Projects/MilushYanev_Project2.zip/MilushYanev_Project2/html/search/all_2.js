var searchData=
[
  ['b',['b',['../jquery_8js.html#aa4026ad5544b958e54ce5e106fa1c805',1,'b():&#160;jquery.js'],['../jquery_8js.html#a2fa551895933fae935a0a6b87282241d',1,'b(function(){if(!b.support.reliableMarginRight){b.cssHooks.marginRight={get:function(bw, bv){var e;b.swap(bw,{display:&quot;inline-block&quot;}, function(){if(bv){e=Z(bw,&quot;margin-right&quot;,&quot;marginRight&quot;)}else{e=bw.style.marginRight}});return e}}}}):&#160;jquery.js']]],
  ['battle',['battle',['../_actor_8h.html#a9f1fc8afafd91b62e36d45f690623ec3',1,'battle(Actor &amp;player, Actor &amp;enemy):&#160;main.cpp'],['../main_8cpp.html#a9f1fc8afafd91b62e36d45f690623ec3',1,'battle(Actor &amp;player, Actor &amp;enemy):&#160;main.cpp']]],
  ['bb',['bb',['../jquery_8js.html#a1d6558865876e1c8cca029fce41a4bdb',1,'jquery.js']]],
  ['block',['block',['../_actor_8h.html#a81aa732ee1c52ed612ce57909dde6b75',1,'block(Actor &amp;player):&#160;main.cpp'],['../main_8cpp.html#a81aa732ee1c52ed612ce57909dde6b75',1,'block(Actor &amp;player):&#160;main.cpp']]],
  ['bonh',['BonH',['../class_bonus.html#aad2515d0e2e8a4e0c6fcbbd01c167712',1,'Bonus']]],
  ['bonus',['Bonus',['../class_bonus.html',1,'Bonus'],['../class_bonus.html#a005571f0961a2e0f1af2befc35d804cf',1,'Bonus::Bonus()']]],
  ['bonuspt_2ecpp',['BonusPt.cpp',['../_bonus_pt_8cpp.html',1,'']]],
  ['bonuspt_2eh',['BonusPt.h',['../_bonus_pt_8h.html',1,'']]],
  ['bq',['bq',['../jquery_8js.html#af6ee77c71b2c89bdb365145ac5ad1219',1,'jquery.js']]],
  ['bs',['bs',['../jquery_8js.html#ae77642f8ef73fb9c20c2a737d956acda',1,'jquery.js']]]
];
