var searchData=
[
  ['resize_2ejs',['resize.js',['../resize_8js.html',1,'']]]
];
