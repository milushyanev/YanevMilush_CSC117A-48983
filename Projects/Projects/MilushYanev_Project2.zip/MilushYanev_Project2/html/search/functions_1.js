var searchData=
[
  ['b',['b',['../jquery_8js.html#a2fa551895933fae935a0a6b87282241d',1,'jquery.js']]],
  ['battle',['battle',['../_actor_8h.html#a9f1fc8afafd91b62e36d45f690623ec3',1,'battle(Actor &amp;player, Actor &amp;enemy):&#160;main.cpp'],['../main_8cpp.html#a9f1fc8afafd91b62e36d45f690623ec3',1,'battle(Actor &amp;player, Actor &amp;enemy):&#160;main.cpp']]],
  ['block',['block',['../_actor_8h.html#a81aa732ee1c52ed612ce57909dde6b75',1,'block(Actor &amp;player):&#160;main.cpp'],['../main_8cpp.html#a81aa732ee1c52ed612ce57909dde6b75',1,'block(Actor &amp;player):&#160;main.cpp']]],
  ['bonh',['BonH',['../class_bonus.html#aad2515d0e2e8a4e0c6fcbbd01c167712',1,'Bonus']]],
  ['bonus',['Bonus',['../class_bonus.html#a005571f0961a2e0f1af2befc35d804cf',1,'Bonus']]]
];
