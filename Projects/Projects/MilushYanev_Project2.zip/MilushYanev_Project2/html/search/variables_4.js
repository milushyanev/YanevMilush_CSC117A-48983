var searchData=
[
  ['date',['date',['../class_developer.html#ad157908ba8bd6ac6b16c8e28502953be',1,'Developer']]]
];
