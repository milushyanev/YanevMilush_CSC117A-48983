var searchData=
[
  ['energy',['energy',['../struct_actor.html#ab3bf461c752924b24b2b9a81250e5274',1,'Actor']]]
];
