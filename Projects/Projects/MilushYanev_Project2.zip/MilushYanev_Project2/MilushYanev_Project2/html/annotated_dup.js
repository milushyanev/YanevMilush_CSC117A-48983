var annotated_dup =
[
    [ "Actor", "struct_actor.html", "struct_actor" ],
    [ "Bonus", "class_bonus.html", "class_bonus" ],
    [ "Creator", "class_creator.html", "class_creator" ],
    [ "Developer", "class_developer.html", "class_developer" ],
    [ "GameDate", "class_game_date.html", "class_game_date" ],
    [ "my_NumberT", "classmy___number_t.html", "classmy___number_t" ]
];