var hierarchy =
[
    [ "Actor", "struct_actor.html", null ],
    [ "Bonus", "class_bonus.html", null ],
    [ "Developer", "class_developer.html", [
      [ "Creator", "class_creator.html", null ]
    ] ],
    [ "GameDate", "class_game_date.html", null ],
    [ "my_NumberT< T >", "classmy___number_t.html", null ],
    [ "my_NumberT< float >", "classmy___number_t.html", null ],
    [ "my_NumberT< int >", "classmy___number_t.html", null ]
];