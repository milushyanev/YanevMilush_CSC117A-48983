var classmy___number_t =
[
    [ "my_NumberT", "classmy___number_t.html#aae9f7035af1da340e063e9618dc642a2", null ],
    [ "my_NumberT", "classmy___number_t.html#a711259667444161bbdc149533e8dd2b8", null ],
    [ "getValue", "classmy___number_t.html#ac987528d323d8a2ed013a200ddb13a5f", null ],
    [ "setValue", "classmy___number_t.html#a0df005c28c1b133efdf67283126fae17", null ]
];