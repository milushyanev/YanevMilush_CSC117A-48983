var class_bonus =
[
    [ "Bonus", "class_bonus.html#a005571f0961a2e0f1af2befc35d804cf", null ],
    [ "~Bonus", "class_bonus.html#ace96cd91925b1f65b2c8596930fed6f5", null ],
    [ "getBonus", "class_bonus.html#a20eafd1e0dc632fbbd86d860822e95bf", null ],
    [ "getMBonus", "class_bonus.html#aaa4cc8b64910ad7fac1a0e2408a26338", null ],
    [ "getNumber", "class_bonus.html#a8410340d40b2c2f94e6975da25715615", null ],
    [ "setNumber", "class_bonus.html#a9b49303ba2ac90ed51903d720c254d16", null ]
];