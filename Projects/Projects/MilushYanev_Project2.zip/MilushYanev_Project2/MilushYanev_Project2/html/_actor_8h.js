var _actor_8h =
[
    [ "Actor", "struct_actor.html", "struct_actor" ],
    [ "battle", "_actor_8h.html#a9f1fc8afafd91b62e36d45f690623ec3", null ],
    [ "block", "_actor_8h.html#a81aa732ee1c52ed612ce57909dde6b75", null ],
    [ "CRTR", "_actor_8h.html#a7c6049047dd1945c70484e3e37847f7b", null ],
    [ "enemyAttack", "_actor_8h.html#a6ed74ea3fa73fdffd3a3bc0199d51910", null ],
    [ "gameManager", "_actor_8h.html#a1fa62b46e875fff4cb5f5ea66f93a671", null ],
    [ "heal", "_actor_8h.html#a4fc2c0136e62f2b645a505e3bd2d75be", null ],
    [ "load", "_actor_8h.html#af3dc1f4eaeaabc4cb2741c991bc47f3d", null ],
    [ "playerAttack", "_actor_8h.html#a0d2f7982285746f2c3086e8c3430c8aa", null ],
    [ "save", "_actor_8h.html#ae37e254cdfd11133af9b06c52f393d6e", null ],
    [ "smack", "_actor_8h.html#a7fffa328a80d69f42c77deccb0c98a2d", null ],
    [ "startMenu", "_actor_8h.html#adb4b7104b34632fd046d9a534eced233", null ],
    [ "startOption", "_actor_8h.html#a9421d775ae363a991198f68d5dbf7b19", null ]
];