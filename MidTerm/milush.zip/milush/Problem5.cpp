#include <iostream>
using namespace std;

int P5()
{
	cout << "Largest factorial for a byte variable is 5!" << endl;
	cout << "Largest factorial for a char variable is 5!" << endl;
	cout << "Largest factorial for a usinged char variable is 5!" << endl;
	cout << "Largest factorial for int is 12!" << endl;
	cout << "Largest factorial for unsigned int is 12!" << endl;
	cout << "Largest factorial for long is 12!" << endl;
	cout << "Largest factorial for short is 7!" << endl;
	cout << "Largest factorial for usigned short is 8!" << endl;
	cout << "Largest factorial for float is  34!" << endl;
	cout << "Largest factorial for double is 170!" << endl;

	
	return 0;
}